function createNewWorld() {
  var world = {}
  var worldElem = document.createElement('div')

  document.body.appendChild(worldElem)
  worldElem.id = 'world'

  world.light = function () {
    worldElem.className += ' light'
  }

  world.add = function(obj) {
    worldElem.appendChild(obj.elem)
  }

  return world
}

function createLittleMing(obj) {
  var elem = obj.elem = document.createElement('img')
  elem.className = 'little-ming'
  elem.title = '身高' + obj.height
  elem.src = 'img/little-ming.png'

  return {
    elem: elem,
    dance: function() {
      elem.className += ' run'
    }
  }
}

function createLittleMingsDog(obj) {
  var elem = obj.elem = document.createElement('img')
  elem.className = 'little-mings-dog'
  elem.title = '有眉毛' + (obj.hasEyeBrow ? '：有' : '：没有')
  elem.src = 'img/little-mings-dog.png'

  return {
    elem: elem,
    dance: function() {
      elem.className += ' run'
    }
  }
}

