var http = require("http"), fs = require('fs');

http
  .createServer(handleClientRequest)
  .listen(3000);

function handleClientRequest (request, response) {
  setResponseHeader(response);
  var cookie = request.headers.cookie;
  if (!cookie) {
    setCookie(response);
    responseWithHomePage(response);
  } else {
    responseWithSecretPage(response, cookie);
  }
}

function setResponseHeader (response) {
  response.statusCode = 200;
  response.setHeader("Content-Type", "text/html");
}

function setCookie (response) {
  response.setHeader("Set-Cookie", "name=MIAC");
}

function responseWithHomePage (response) {
  responseWithHTMLFile('index.html', response);
}

function responseWithSecretPage (response, cookie) {
  var name = getNameFromCookie(cookie);
  if (name) {
    var html = "<html><body><h1>" + name + "</h1></body></html>";
    response.end(html);
  } else {
    responseWithHTMLFile('index.html', response);
  }

}

function getNameFromCookie (cookie) {
  return cookie.split('=')[1];
}

function responseWithHTMLFile (filename, response) {
  fs.readFile(filename, 'utf8', function (err, data) {
    if (err) {
      throw err;
    } else {
      response.end(data);
    }
  });
}
