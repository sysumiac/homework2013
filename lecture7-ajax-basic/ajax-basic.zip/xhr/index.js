
var http = require('http');
var fs = require('fs');
var url = require('url');
var handler = {
  '/': handler,
  '/xml': xmlHandler,
  '/jquery': jqueryHandler
};

var server = http.createServer(function (req, res) {
  var pathname = url.parse(req.url).pathname;
  if (typeof handler[pathname] === 'function') {
    handler[pathname](req, res);
  }
});

function handler(req, res) {
  res.writeHead(200, {
    // 'Access-Control-Allow-Credentials': true,
    'Content-Type': 'text/html'
  });
  fs.readFile('xhr.html', function(err, data) {
    res.write(data);
    res.end();
  });
}

function xmlHandler(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/xml'
  });
  var content = fs.readFileSync('./simpleResponse.xml');
  res.write(content);
  res.end();
}

function jqueryHandler(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/plain'
  });
  res.write('<strong>You are using $.ajax</strong>');
  res.end();
}

server.listen(8888);

console.log('Server Started.');